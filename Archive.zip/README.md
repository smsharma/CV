# CV

LaTeX CV. (Automatically) Compiled version in https://github.com/smsharma/CV/tree/master-pdf.
